package br.com.caelum.vraptor.controller;

import br.com.caelum.vraptor.Controller;

@Controller
public class IndexController {

	
	public IndexController() {
		
	}
	
	public void home() {
		
	}
}
